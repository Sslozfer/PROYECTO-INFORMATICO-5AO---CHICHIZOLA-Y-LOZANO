// companies.controller.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { CompaniesController } from './companies.controller';
import { CompaniesService } from './companies.service';

describe('CompaniesController', () => {
  let controller: CompaniesController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CompaniesController],
      providers:   [{ provide: CompaniesService, useValue: { create: jest.fn(), findAll: jest.fn(), findOne: jest.fn(), update: jest.fn(), verifyDomain: jest.fn() } }],
    }).compile();
    controller = module.get<CompaniesController>(CompaniesController);
  });

  it('should be defined', () => expect(controller).toBeDefined());
});